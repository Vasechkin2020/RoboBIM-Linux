#!/bin/sh

# http://ipkg.nslu2-linux.org/feeds/optware/cs08q1armel/cross/unstable/

/opt/bin/sudo ipkg-opt install $*
